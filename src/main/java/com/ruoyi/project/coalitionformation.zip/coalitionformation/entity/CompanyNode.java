package com.ruoyi.project.coalitionformation.entity;

import lombok.Data;

@Data
public class CompanyNode {
  private int id;
  private String name;
  private double value;
  private int layer_id;
  private int category;
}
