package com.ruoyi.project.coalitionformation.entity;

import lombok.Data;

@Data
public class Resource {
  Integer id;
  String name;
  Integer num;
}
